package com.example.van

data class VanData(val name:String = "", val phone:String = "", val pic:String = "", val price:Int = -1)