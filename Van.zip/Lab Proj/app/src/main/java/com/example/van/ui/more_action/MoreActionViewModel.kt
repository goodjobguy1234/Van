package com.example.van.ui.more_action

import androidx.lifecycle.ViewModel

class MoreActionViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}